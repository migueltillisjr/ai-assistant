# ai-assistant
ai-assistant

## High Level Requirements
- python3.11
- apache2
- OpenAi API Key, replace the "OPENAI_API_KEY" variable with your key

## Run it at the Cli
```shell
chmod +x assistant.py
./assistant.py
```
